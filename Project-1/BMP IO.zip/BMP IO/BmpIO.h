// BmpIO.h: interface of the BMP file I/O class
//
// Copyright 1999 Qingmin LIAO
///////////////////////////////////////////////////////////////////////////

#if !defined(BMP_FILE_IO_CLASS)
#define BMP_FILE_IO_CLASS

#include "math.h"

// Handle to a BMP
DECLARE_HANDLE(HBMP);

// BMP Header Marker - used in writing BMPs to files
#define BMP_HEADER_MARKER   ((WORD) ('M' << 8) | 'B')

// BMP constants
#define PALVERSION   0x300

// BMP Macros
#define RECTWIDTH(lpRect)	((lpRect)->right - (lpRect)->left)
#define RECTHEIGHT(lpRect)	((lpRect)->bottom - (lpRect)->top)

// WIDTHBYTES performs DWORD-aligning of BMP scanlines.  The "bits"
// parameter is the bit count for the scanline (biWidth * biBitCount),
// and this macro returns the number of DWORD-aligned bytes needed
// to hold those bits.

#define WIDTHBYTES(bits)    (((bits) + 31) / 32 * 4)

/*
 * Pointer to a monochrome image:
 *     origin (0,0) is on the top-left of image
 */
typedef	int **	PMONOIMA;

PMONOIMA	WINAPI	AllocPMONOIMA (CSize);
void		WINAPI	FreePMONOIMA (PMONOIMA, CSize);

PMONOIMA	WINAPI	Bmp8toImage (HBMP);
HBMP		WINAPI	ImagetoBmp8 (PMONOIMA, CSize);
BOOL		WINAPI	SaveBmp8toFile (LPCTSTR, HBMP);

/*
 * Pointer to a color image:
 *     origin (0,0)   -- Top-Left of image
 *     image[0][x][y] -- Red component
 *     image[1][x][y] -- Green component
 *     image[2][x][y] -- Blue component
 */
typedef	int ***	PCOLORIMA;

PCOLORIMA	WINAPI	AllocPCOLORIMA (int ncolor, CSize);
void		WINAPI	FreePCOLORIMA (PCOLORIMA, int ncolor, CSize);

PCOLORIMA	WINAPI	Bmp24toImage (HBMP);
HBMP		WINAPI	ImagetoBmp24 (PCOLORIMA, CSize);
BOOL		WINAPI	SaveBmp24toFile (LPCTSTR, HBMP);


///////////////////////////////////////////////////////////////////////////
// declaration of CBmpIO class

class CBmpIO : public CDocument
{
public:
	CBmpIO();
	~CBmpIO();

// Attributes
protected:
	HBMP		m_hBmp;
	CPalette*	m_palBmp;
	CSize		m_sizeBmp;
	CString		m_infoBmp;

public:
	HBMP		GetHBmp() const
					{ return m_hBmp; }
	CPalette*	GetBmpPalette() const
					{ return m_palBmp; }
	CSize		GetBmpSize() const
					{ return m_sizeBmp; }
	CString		GetBmpInfo() const
					{ return m_infoBmp; }

// Operations
public:
	void		InitBmpData (LPCTSTR);
	void		ReplaceHBmp (HBMP);

// Function prototypes
public:
	BOOL	PaintBmp (CDC*);
	BOOL	CreateBmpPalette (HBMP, CPalette*);
	LPSTR	FindBmpBits (LPSTR);
	WORD	PaletteSize (LPSTR);
	WORD	BmpNumColors (LPSTR);
	HGLOBAL	CopyHandle (HGLOBAL);

	HBMP	OpenBmp (CFile&);
	BOOL	OpenBmpFile (LPCTSTR);
	BOOL	SaveBmp (HBMP, CFile&);
	BOOL	SaveBmpFile (LPCTSTR, HBMP);
};

#endif // !defined(BMP_FILE_IO_CLASS)
