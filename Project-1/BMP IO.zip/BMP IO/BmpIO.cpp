// BmpIO.cpp: implementation of the BMP file I/O classes
//
// Copyright 2002 Qingmin LIAO
///////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BmpIO.h"

/*************************************************************************
 *
 * Function:  AllocPMONOIMA ()
 *
 * Purpose:   Allocate memory for the image data structure
 *
 * Returns:   pointer to the memory.
 *
 ************************************************************************/


PMONOIMA WINAPI AllocPMONOIMA(CSize cs)
{
	PMONOIMA pIma = (int **) calloc((unsigned) cs.cx, sizeof(int *));
	for (int i = 0; i < cs.cx; i++)
	{
		pIma[i] = (int *) calloc((unsigned) cs.cy, sizeof(int));
		if (pIma[i] == 0)
			return NULL;
	}

	return pIma;
}


/*************************************************************************
 *
 * Function:  FreePMONOIMA ()
 *
 * Purpose:   Free memory for the image data structure
 *
 ************************************************************************/


void WINAPI FreePMONOIMA(PMONOIMA pMim, CSize cs)
{
	for (int i = 0; i < cs.cx; i++)
		free((char*) pMim[i]);

	free((char*) pMim);
}


/*************************************************************************
 *
 * Function:  AllocPCOLORIMA ()
 *
 * Purpose:   Allocate memory for the image data structure
 *
 * Returns:   pointer to the memory.
 *
 ************************************************************************/


PCOLORIMA WINAPI AllocPCOLORIMA(int ncolor, CSize cs)
{
	PCOLORIMA	pIma;
	int			n, i;

	pIma = (PCOLORIMA) calloc((unsigned) ncolor, sizeof(int **));
	if (pIma == 0)
		return NULL;
	for (n = 0; n < ncolor; n++)
	{
		pIma[n] = (int **) calloc((unsigned) cs.cx, sizeof(int *));
		if (pIma[n] == 0)
			return NULL;
		for (i = 0; i < cs.cx; i++)
		{
			pIma[n][i] = (int *) calloc((unsigned) cs.cy, sizeof(int));
			if (pIma[n][i] == 0)
				return NULL;
		}
	}

	return pIma;
}


/*************************************************************************
 *
 * Function:  FreePCOLORIMA ()
 *
 * Purpose:   Free memory for the image data structure
 *
 ************************************************************************/


void WINAPI FreePCOLORIMA(PCOLORIMA pCim, int ncolor, CSize cs)
{
	int			n, i;

	for (n = 0; n < ncolor; n++)
	{
		for (i = 0; i < cs.cx; i++)
			free((char*) pCim[n][i]);
		free((char*) pCim[n]);
	}
	free((char*) pCim);
}


/*************************************************************************
 *
 * Function:  Bmp8toImage (HBMP)
 *
 * Purpose:   Load the image data structure from the BMP data (8 bits)
 *
 * Returns:   A pointer to a new PMONOIMA memory (MnIm) if successful.
 *			  NULL if an error occurs.
 *
 * Comments:  used in the image processing functions.
 *
 ************************************************************************/


PMONOIMA WINAPI Bmp8toImage(HBMP hBmp)
{
	LPBITMAPINFOHEADER	lpbmi;		// pointer to a BMP
	LPSTR				lpBmpBits;	// Pointer to BMP bits
	PMONOIMA			MnIm;		// Pointer to image data

	//LPSTR	pBmp = (LPSTR) ::GlobalLock((HGLOBAL) hBmp);
	lpbmi = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) hBmp);//pBmp;
	if ((int) lpbmi->biBitCount != 8)
		return NULL;
	
	// Get the image size: cxBmp x cyBmp
	int cxBmp = (int) lpbmi->biWidth;
	int cyBmp = (int) lpbmi->biHeight;

	// Allocate memory for image data MnIm[x][y]:
	//     MnIm[0][0] -- Top-Left of image
	MnIm = (PMONOIMA) ::AllocPMONOIMA(CSize(cxBmp, cyBmp));
	if (MnIm == 0)
	{
		//CString note = "Cannot allocate 'MnIm' in Bmp8toImage().";
		CString note("Cannot allocate 'MnIm' in Bmp8toImage().");
		MessageBox(NULL, note, NULL, MB_ICONERROR | MB_OK);
		return NULL;
	}

	// Find pointer to the BMP data:
	//   BmpInfoHdr + Size of BmpInfoHdr (stored in the first DWORD) + Size of color palette
	int	sizepal = 256 * sizeof(RGBQUAD);
	lpBmpBits = (LPSTR) ((LPSTR) lpbmi + *(LPDWORD)lpbmi + sizepal);

	// Load BMP data into image data
	for (int y = cyBmp - 1; y >= 0; y--)	// origin(0,0): BMP(Bottom-Left) != IM(Top-Left)
	{
		for (int x = 0; x < cxBmp; x++)
		{
			MnIm[x][y] = (UCHAR) *lpBmpBits;
			lpBmpBits++;
		}
		// For the BMP format file, each line must have:
		//     ((cxBmp + 3) / 4) * 4  (i.e. n*4) bytes
		// but for the image data (8 bits), each line have only:
		//     cxBmp bytes.
		// So it's necessary to add lpBmpBits by the following increment:
		lpBmpBits += ((cxBmp + 3) / 4) * 4 - cxBmp;
	}

	::GlobalUnlock((HGLOBAL) hBmp);

	return MnIm;
}


/*************************************************************************
 *
 * Function:  Bmp24toImage (HBMP)
 *
 * Purpose:   Load the image data structure from the BMP data (24 bits)
 *
 * Returns:   A pointer to a new PCOLORIMA memory (ClrIm) if successful.
 *			  NULL if an error occurs.
 *
 * Comments:  used in the image processing functions.
 *
 ************************************************************************/


PCOLORIMA WINAPI Bmp24toImage(HBMP hBmp)
{
	LPBITMAPINFOHEADER	lpbmi;		// pointer to a BMP
	LPSTR				lpBmpBits;	// Pointer to BMP bits
	PCOLORIMA			ClrIm;		// Pointer to image data

	lpbmi = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) hBmp);
	if ((int) lpbmi->biBitCount != 24)
		return NULL;
	
	// Get the image size: cxBmp x cyBmp
	int cxBmp = (int) lpbmi->biWidth;
	int cyBmp = (int) lpbmi->biHeight;

	// Allocate memory for image data ClrIm[RGB][x][y]:
	//     ClrIm[0-R,1-G,2-B][0][0] -- Top-Left of image
	ClrIm = (PCOLORIMA) ::AllocPCOLORIMA(3, CSize(cxBmp, cyBmp));
	if (ClrIm == 0)
	{
		CString note = "Cannot allocate 'ClrIm' in Bmp24toImage().";
		MessageBox(NULL, note, NULL, MB_ICONERROR | MB_OK);
		return NULL;
	}

	// Find pointer to the BMP data:
	//   BmpInfoHdr + Size of BmpInfoHdr (stored in the first DWORD)
	lpBmpBits = (LPSTR) ((LPSTR) lpbmi + *(LPDWORD)lpbmi);

	// Load BMP data into image data
	for (int y = cyBmp - 1; y >= 0; y--)
		// origin(0,0): BMP(Bottom-Left) != IM(Top-Left)
	{
		for (int x = 0; x < cxBmp; x++)
		{
			for (int n = 2; n >= 0; n--)
				// different color order: BMP(BGR) != IM(RGB)
			{
				ClrIm[n][x][y] = (UCHAR) *lpBmpBits;
				lpBmpBits++;
			}
		}
		// For the BMP format file, each line must have:
		//     ((cxBmp * 3 + 3) / 4) * 4  (i.e. n*4) bytes
		// but for the image data (24 bits), each line have only:
		//     cxBmp * 3 bytes.
		// So it's necessary to add lpBmpBits by the following increment:
		lpBmpBits += ((cxBmp * 3 + 3) / 4) * 4 - cxBmp * 3;
	}

	::GlobalUnlock((HGLOBAL) hBmp);

	return ClrIm;
}


/*************************************************************************
 *
 * Function:  ImagetoBmp24 ()
 *
 * Purpose:   Put the image data structure into the BMP data (24 bits)
 *
 * Returns:   A handle to a new BMP (hBmp) if successful.
 *			  NULL if an error occurs.
 *
 ************************************************************************/


HBMP WINAPI ImagetoBmp24(PCOLORIMA ClrIm, CSize cs)
{
	LPBITMAPINFOHEADER lpbmi;  // pointer to a BMP
	LPSTR	lpBmpBits;         // Pointer to BMP bits
	HBMP	hBmp;
	LPSTR	pBmp;
	int		cx = cs.cx;
	int		cy = cs.cy;
	int		offset;	// byte number to complement each line into n*4 bytes

	// Calculate the size of BMP: 
	//     sum of BmpInfoHeader (40 bytes) and image size in bytes
	offset = ((cx * 3 + 3) / 4) * 4 - cx * 3;
	long TotalBmpBytes = (long) sizeof(BITMAPINFOHEADER) 
		                 + (cx * 3 + offset) * cy;

	// Allocate memory for BMP
	hBmp = (HBMP) ::GlobalAlloc(GHND, TotalBmpBytes);
	if (hBmp == 0)
	{
		return NULL;
	}

	pBmp = (LPSTR) ::GlobalLock((HGLOBAL) hBmp);

	// get pointer to BITMAPINFO
	lpbmi = (LPBITMAPINFOHEADER) pBmp;

	// Load BMP info header
	lpbmi->biSize			= (long) sizeof(BITMAPINFOHEADER);
	lpbmi->biWidth			= (long) cx;
	lpbmi->biHeight			= (long) cy;
	lpbmi->biPlanes			= (int)   1;
	lpbmi->biBitCount		= (int)  24;		// B-8bit G-8bit R-8bit
	lpbmi->biCompression	= (long)  0;
	lpbmi->biSizeImage		= (long) cx * cy * 3;	// may be zero
	lpbmi->biXPelsPerMeter	= (long) 0;
	lpbmi->biYPelsPerMeter	= (long) 0;
	lpbmi->biClrUsed		= (long) 0;
	lpbmi->biClrImportant	= (long) 0;

	// Find pointer to the BMP data:
	//   BmpInfoHdr + Size of BmpInfoHdr (stored in the first DWORD)
	lpBmpBits = (LPSTR) ((LPSTR) lpbmi + *(LPDWORD)lpbmi);

	// Load BMP data from image data
	for (int y = cy - 1; y >= 0; y--)
		// origin(0,0): BMP(Bottom-Left) != IM(Top-Left)
	{
		for (int x = 0; x < cx; x++)
		{
			for (int n = 2; n >= 0; n--)
				// different color order: BMP(BGR) != IM(RGB)
			{
				*lpBmpBits = (BYTE) ClrIm[n][x][y];
				lpBmpBits++;
			}
		}
		// For the BMP format file, each line must have:
		//     ((cxBmp * 3 + 3) / 4) * 4  (i.e. n*4) bytes
		// but for the image data (24 bits), each line have only:
		//     cxBmp * 3 bytes.
		// So it's necessary to increase lpBmpBits by the following offset:
		lpBmpBits += offset;
	}

	::GlobalUnlock((HGLOBAL) hBmp);
	return hBmp;
}


/*************************************************************************
 *
 * Function:  SaveBmp24toFile (LPCTSTR, HBMP)
 *
 * Purpose:   Save the specified BMP file
 *
 * Returns:   TRUE if successful, else FALSE.
 *
 ************************************************************************/


BOOL WINAPI SaveBmp24toFile(LPCTSTR lpszPathName, HBMP hBmp)
{
	CFile file;
	CFileException fe;

	if (hBmp == NULL)
		return FALSE;

	if (!file.Open(lpszPathName, CFile::modeCreate |
	  CFile::modeReadWrite | CFile::shareExclusive, &fe))
	{
		CString	str = (CString) "Cannot create the file:\n";
		str += (CString) lpszPathName;
		MessageBox(NULL, str, NULL, MB_ICONERROR | MB_OK);
		return FALSE;
	}

	// replace calls to Serialize with SaveBmp function
	BOOL bSuccess = FALSE;
	TRY
	{
		BITMAPFILEHEADER bmfHdr; // Header for Bitmap file
		LPBITMAPINFOHEADER lpbi;   // Pointer to BMP info structure
		DWORD dwBmpSize;

		// Get a pointer to the BMP memory, the first
		// of which contains a BITMAPINFO structure
		lpbi = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) hBmp);
		if (lpbi != NULL)
		{
			/* Fill in the fields of the file header */

			// Fill in file type (first 2 bytes must be "BM" for a bitmap)
			bmfHdr.bfType = BMP_HEADER_MARKER;  // "BM"

			// Find the size of header: the first DWORD in BITMAPINFOHEADER
			dwBmpSize = *(LPDWORD)lpbi;  // Partial Calculation

			// Calculate the size of Bitmap Bits only: 
			//     Width (DWORD aligned) * Height
			DWORD dwBmBitsSize;  
			dwBmBitsSize = WIDTHBYTES((lpbi->biWidth)*((DWORD)lpbi->biBitCount))
							* lpbi->biHeight;

			dwBmpSize += dwBmBitsSize;

			// Fill the correct size in the biSizeImage field
			lpbi->biSizeImage = dwBmBitsSize;

			// Calculate file size by adding BMP size to sizeof(BITMAPFILEHEADER)
			bmfHdr.bfSize = dwBmpSize + sizeof(BITMAPFILEHEADER);
			bmfHdr.bfReserved1 = 0;
			bmfHdr.bfReserved2 = 0;
		
			/*
			 * Now, calculate the offset the actual bitmap bits will be in
			 * the file -- It's the Bitmap file header plus the BMP header.
			 */
			bmfHdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + lpbi->biSize;

			TRY
			{
				// Write the file header
				file.Write((LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER));
				// Write the BMP header and the bits
				file.WriteHuge(lpbi, dwBmpSize);
			}
			CATCH (CFileException, e)
			{
				::GlobalUnlock((HGLOBAL) hBmp);
				THROW_LAST();
			}
			END_CATCH

			::GlobalUnlock((HGLOBAL) hBmp);
			bSuccess = TRUE;
		}
		file.Close();
	}
	CATCH (CException, eSave)
	{
		file.Abort(); // will not throw an exception
		CString strMsg = (CString) "Failed to save BMP file:\n";
		strMsg += (CString) lpszPathName;
		MessageBox(NULL, strMsg, NULL, MB_ICONERROR | MB_OK);
		bSuccess = FALSE;
	}
	END_CATCH

	return bSuccess;
}


/*************************************************************************
 *
 * Function:  ImagetoBmp8 ()
 *
 * Purpose:   Put the image data structure into the BMP data (8 bits)
 *
 * Returns:   A handle to a new BMP (hBmp) if successful.
 *			  NULL if an error occurs.
 *
 ************************************************************************/


HBMP WINAPI ImagetoBmp8(PMONOIMA pMonoIm, CSize cs)
{
	HBMP	hBmp;
	LPSTR	pBmp;
	int		cx = cs.cx;
	int		cy = cs.cy;
	int		offset;	// byte number to complement each line into n*4 bytes
	int		sizepal;

	// Calculate the size of BMP: 
	//     sum of BmpInfoHeader (40 bytes), RGBQUAD and image size in bytes
	offset = ((cx + 3) / 4) * 4 - cx;
	sizepal = 256 * sizeof(RGBQUAD);
	long TotalBmpBytes = (long) sizeof(BITMAPINFOHEADER) 
						 + sizepal + (cx + offset) * cy;

	// Allocate memory for BMP
	hBmp = (HBMP) ::GlobalAlloc(GHND, TotalBmpBytes);
	if (hBmp == 0)
	{
		return NULL;
	}

	pBmp = (LPSTR) ::GlobalLock((HGLOBAL) hBmp);

	// Find pointer to BITMAPINFO
	LPBITMAPINFOHEADER lpbmi;  // pointer to a BMP
	lpbmi = (LPBITMAPINFOHEADER) pBmp;

	// Load BMP info header
	lpbmi->biSize			= (long) sizeof(BITMAPINFOHEADER);
	lpbmi->biWidth			= (long) cx;
	lpbmi->biHeight			= (long) cy;
	lpbmi->biPlanes			= (int)  1;
	lpbmi->biBitCount		= (int)  8;			// 256 grey
	lpbmi->biCompression	= (long) 0;
	lpbmi->biSizeImage		= (long) cx * cy;	// may be zero
	lpbmi->biXPelsPerMeter	= (long) 0;
	lpbmi->biYPelsPerMeter	= (long) 0;
	lpbmi->biClrUsed		= (long) 0;
	lpbmi->biClrImportant	= (long) 0;

	// Find pointer to the RGBQUAD data: the color palette
	LPBITMAPINFO	lpbm;
	lpbm = (LPBITMAPINFO) pBmp;

	// Load the color palette
	for (int i = 0; i < 256; i++)
	{
		lpbm->bmiColors[i].rgbBlue  = (UCHAR) i;
		lpbm->bmiColors[i].rgbGreen = (UCHAR) i;
		lpbm->bmiColors[i].rgbRed   = (UCHAR) i;
		lpbm->bmiColors[i].rgbReserved = (UCHAR) 0;
	}

	// Find pointer to the BMP data
	LPSTR	lpBmpBits;         // Pointer to BMP bits
	lpBmpBits = (LPSTR) ((LPSTR) lpbmi + *(LPDWORD)lpbmi + sizepal);

	// Load BMP data from image data
	for (int y = cy - 1; y >= 0; y--)
		// origin(0,0): BMP(Bottom-Left) != IM(Top-Left)
	{
		for (int x = 0; x < cx; x++)
		{
			*lpBmpBits = (BYTE) pMonoIm[x][y];
			lpBmpBits++;
		}
		// For the BMP format file, each line must have:
		//     ((cxBmp + 3) / 4) * 4  (i.e. n*4) bytes
		// but for the image data (8 bits), each line have only:
		//     cxBmp bytes.
		// So it's necessary to increase lpBmpBits by the offset.
		lpBmpBits += offset;
	}

	::GlobalUnlock((HGLOBAL) hBmp);
	return hBmp;
}


/*************************************************************************
 *
 * Function:  SaveBmp8toFile (LPCTSTR, HBMP)
 *
 * Purpose:   Save the specified 8bit BMP file
 *
 * Returns:   TRUE if successful, else FALSE.
 *
 ************************************************************************/


BOOL WINAPI SaveBmp8toFile(LPCTSTR lpszPathName, HBMP hBmp)
{
	CFile file;
	CFileException fe;

	if (hBmp == NULL)
		return FALSE;

	if (!file.Open(lpszPathName, CFile::modeCreate |
	  CFile::modeReadWrite | CFile::shareExclusive, &fe))
	{
		CString	str = (CString) "Cannot create the file:\n";
		str += (CString) lpszPathName;
		MessageBox(NULL, str, NULL, MB_ICONERROR | MB_OK);
		return FALSE;
	}

	// replace calls to Serialize with SaveBmp function
	BOOL bSuccess = FALSE;
	TRY
	{
		BITMAPFILEHEADER bmfHdr; // Header for Bitmap file
		LPBITMAPINFOHEADER lpbi;   // Pointer to BMP info structure
		DWORD dwBmpSize;

		// Get a pointer to the BMP memory, the first
		// of which contains a BITMAPINFO structure
		lpbi = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) hBmp);
		if (lpbi != NULL)
		{
			/* Fill in the fields of the file header */

			// Fill in file type (first 2 bytes must be "BM" for a bitmap)
			bmfHdr.bfType = BMP_HEADER_MARKER;  // "BM"

			// First, find size of header plus size of color table.  Since the
			// first DWORD in both BITMAPINFOHEADER and BITMAPCOREHEADER conains
			// the size of the structure, let's use this.
			dwBmpSize = *(LPDWORD)lpbi + 256 * sizeof(RGBQUAD);  // Partial Calculation

			// Calculate the size of Bitmap Bits only: 
			//     Width (DWORD aligned) * Height
			DWORD dwBmBitsSize;  
			dwBmBitsSize = WIDTHBYTES((lpbi->biWidth)*((DWORD)lpbi->biBitCount))
							* lpbi->biHeight;

			dwBmpSize += dwBmBitsSize;

			// Fill the correct size in the biSizeImage field
			lpbi->biSizeImage = dwBmBitsSize;

			// Calculate file size by adding BMP size to sizeof(BITMAPFILEHEADER)
			bmfHdr.bfSize = dwBmpSize + sizeof(BITMAPFILEHEADER);
			bmfHdr.bfReserved1 = 0;
			bmfHdr.bfReserved2 = 0;
		
			/*
			 * Now, calculate the offset the actual bitmap bits will be in
			 * the file -- It's the Bitmap file header plus the BMP header,
			 * plus the size of color table.
			 */
			bmfHdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + lpbi->biSize
				              + 256 * sizeof(RGBQUAD);

			TRY
			{
				// Write the file header
				file.Write((LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER));
				// Write the BMP header and the bits
				file.WriteHuge(lpbi, dwBmpSize);
			}
			CATCH (CFileException, e)
			{
				::GlobalUnlock((HGLOBAL) hBmp);
				THROW_LAST();
			}
			END_CATCH

			::GlobalUnlock((HGLOBAL) hBmp);
			bSuccess = TRUE;
		}
		file.Close();
	}
	CATCH (CException, eSave)
	{
		file.Abort(); // will not throw an exception
		CString strMsg = (CString) "Failed to save BMP file:\n";
		strMsg += (CString) lpszPathName;
		MessageBox(NULL, strMsg, NULL, MB_ICONERROR | MB_OK);
		bSuccess = FALSE;
	}
	END_CATCH

	return bSuccess;
}

	
///////////////////////////////////////////////////////////////////////////
// CBmpIO construction/destruction
///////////////////////////////////////////////////////////////////////////

CBmpIO::CBmpIO()
{
	m_hBmp = NULL;
	m_palBmp = NULL;
	m_sizeBmp = CSize(1,1);     // dummy value to make CScrollView happy
}

CBmpIO::~CBmpIO()
{
	if (m_hBmp != NULL)
	{
		::GlobalFree((HGLOBAL) m_hBmp);
	}
	if (m_palBmp != NULL)
	{
		delete m_palBmp;
	}
}


///////////////////////////////////////////////////////////////////////////
// CBmpIO operations
///////////////////////////////////////////////////////////////////////////

void CBmpIO::InitBmpData(LPCTSTR lpszPathName)
{
	if (m_palBmp != NULL)
	{
		delete m_palBmp;
		m_palBmp = NULL;
	}
	if (m_hBmp == NULL)
	{
		return;
	}

	// Set up document size
	LPBITMAPINFOHEADER lpbmi;  // pointer to a BMP
	lpbmi = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) m_hBmp);
	int cxBmp = (int) lpbmi->biWidth;
	int cyBmp = (int) lpbmi->biHeight;
	if (cxBmp > INT_MAX || cyBmp > INT_MAX)
	{
		::GlobalUnlock((HGLOBAL) m_hBmp);
		::GlobalFree((HGLOBAL) m_hBmp);
		m_hBmp = NULL;
		CString strMsg;
		strMsg = "BMP is too large";
		MessageBox(NULL, strMsg, NULL, MB_ICONERROR | MB_OK);
		return;
	}
	m_sizeBmp = CSize(cxBmp, cyBmp);

	// Set up BMP information
	m_infoBmp = (CString)     "File name:    " + lpszPathName;
	char strbuff[30];
	_itoa(cxBmp, strbuff, 10);
	m_infoBmp = m_infoBmp + "\nImage Size:   " + strbuff + " x ";
	_itoa(cyBmp, strbuff, 10);
	m_infoBmp = m_infoBmp + strbuff + " (WxH)";
	_itoa((int) lpbmi->biBitCount, strbuff, 10);
	m_infoBmp = m_infoBmp + "\nColor Number: " + strbuff + " bits";

//	_ltoa((long) lpbmi->biSizeImage, strbuff, 10);
//	m_infoBmp = m_infoBmp + "\nImage size:   " + strbuff + " bytes";
//	_ltoa((long) lpbmi->biXPelsPerMeter, strbuff, 10);
//	m_infoBmp = m_infoBmp + "\nX per meter:  " + strbuff + " pixels";
//	_ltoa((long) lpbmi->biYPelsPerMeter, strbuff, 10);
//	m_infoBmp = m_infoBmp + "\nY per meter:  " + strbuff + " pixels";
//	_ltoa((long) lpbmi->biClrUsed, strbuff, 10);
//	m_infoBmp = m_infoBmp + "\nColor used:   " + strbuff + " colors";
//	_ltoa((long) lpbmi->biClrImportant, strbuff, 10);
//	m_infoBmp = m_infoBmp + "\nClrImportant: " + strbuff + " colors";

	::GlobalUnlock((HGLOBAL) m_hBmp);

	// Create copy of palette
	m_palBmp = new CPalette;
	if (m_palBmp == NULL)
	{
		// we must be really low on memory
		::GlobalFree((HGLOBAL) m_hBmp);
		m_hBmp = NULL;
		return;
	}
	if (CreateBmpPalette(m_hBmp, m_palBmp) == NULL)
	{
		// BMP may not have a palette
		delete m_palBmp;
		m_palBmp = NULL;
		return;
	}
}

void CBmpIO::ReplaceHBmp(HBMP hBmp)
{
	if (m_hBmp != NULL)
	{
		::GlobalFree((HGLOBAL) m_hBmp);
	}
	m_hBmp = hBmp;
}


/*************************************************************************
 *
 * PaintBmp()
 *
 * Parameters:
 *
 * CDC* pDC         - pointer to the specified DC
 *
 * Return Value:
 *
 * BOOL             - TRUE if BMP was drawn, FALSE otherwise
 *
 * Description:
 *   Painting routine for the BMP (m_hBmp).  Calls StretchDIBits() or
 *   SetDIBitsToDevice() to paint the BMP.  The BMP is output to the 
 *   specified DC, at the coordinates given in rcDest.  The area of the
 *   BMP to be output is given by rcBmp.
 *
 ************************************************************************/

BOOL CBmpIO::PaintBmp(CDC* pDC)
{
	HDC     hDC = pDC->m_hDC;	// DC to do output to
	CRect rcBmp;				// rectangle of BMP to output into rcDest
	CRect rcDest;				// rectangle on DC to do output to

	LPSTR    lpBmpHdr;			// Pointer to BITMAPINFOHEADER
	LPSTR    lpBmpBits;			// Pointer to BMP bits
	BOOL     bSuccess=FALSE;	// Success/fail flag
	HPALETTE hPal=NULL;			// Our BMP's palette
	HPALETTE hOldPal=NULL;		// Previous palette

	/* Check for valid BMP handle */
	if (m_hBmp == NULL)
		return FALSE;

	/* determine rcBMP and rcDest according to the DC */
	rcBmp = CRect(CPoint(0, 0), m_sizeBmp);
	if (pDC->IsPrinting())   // printer DC
	{
		// get size of printer page (in pixels)
		int cxPage = pDC->GetDeviceCaps(HORZRES);
		int cyPage = pDC->GetDeviceCaps(VERTRES);
		// get printer pixels per inch
		int cxInch = pDC->GetDeviceCaps(LOGPIXELSX);
		int cyInch = pDC->GetDeviceCaps(LOGPIXELSY);

		//
		// Best Fit case -- create a rectangle which preserves
		// the DIB's aspect ratio, and fills the page horizontally.
		//
		// The formula in the "->bottom" field below calculates the Y
		// position of the printed bitmap, based on the size of the
		// bitmap, the width of the page, and the relative size of
		// a printed pixel (cyInch / cxInch).
		//
		rcDest.top = rcDest.left = 0;
		double cxBmp = m_sizeBmp.cx;
		double cyBmp = m_sizeBmp.cy;
		rcDest.bottom = (int)((cyBmp*cxPage*cyInch)	/ (cxBmp*cxInch));
		rcDest.right = cxPage;
	}
	else   // not printer DC
	{
		rcDest = rcBmp;
	}

	/* Lock down the BMP, and get a pointer to the beginning of the bit
	 *  buffer
	 */
	lpBmpHdr  = (LPSTR) ::GlobalLock((HGLOBAL) m_hBmp);
	lpBmpBits = FindBmpBits(lpBmpHdr);

	// Get the BMP's palette, then select it into DC
	if (m_palBmp != NULL)
	{
		hPal = (HPALETTE) m_palBmp->m_hObject;

		// Select as background since we have
		// already realized in forground if needed
		hOldPal = ::SelectPalette(hDC, hPal, TRUE);
	}

	/* Make sure to use the stretching mode best for color pictures */
	::SetStretchBltMode(hDC, COLORONCOLOR);

	/* Determine whether to call StretchDIBits() or SetDIBitsToDevice() */
	LPBITMAPINFOHEADER lpbmi;  // pointer to a BMP
	lpbmi = (LPBITMAPINFOHEADER) lpBmpHdr;
	if ((RECTWIDTH(&rcDest)  == RECTWIDTH(&rcBmp)) &&
	   (RECTHEIGHT(&rcDest) == RECTHEIGHT(&rcBmp)))
		bSuccess = ::SetDIBitsToDevice(hDC,                    // hDC
								   rcDest.left,             // DestX
								   rcDest.top,              // DestY
								   RECTWIDTH(&rcDest),        // nDestWidth
								   RECTHEIGHT(&rcDest),       // nDestHeight
								   rcBmp.left,            // SrcX
								   (int)lpbmi->biHeight -
									  rcBmp.top -
									  RECTHEIGHT(&rcBmp),   // SrcY
								   0,                          // nStartScan
								   (WORD)lpbmi->biHeight,      // nNumScans
								   lpBmpBits,                  // lpBits
								   (LPBITMAPINFO)lpBmpHdr,     // lpBitsInfo
								   DIB_RGB_COLORS);            // wUsage
   else
	  bSuccess = ::StretchDIBits(hDC,                          // hDC
							   rcDest.left,                 // DestX
							   rcDest.top,                  // DestY
							   RECTWIDTH(&rcDest),            // nDestWidth
							   RECTHEIGHT(&rcDest),           // nDestHeight
							   rcBmp.left,                // SrcX
							   rcBmp.top,                 // SrcY
							   RECTWIDTH(&rcBmp),           // wSrcWidth
							   RECTHEIGHT(&rcBmp),          // wSrcHeight
							   lpBmpBits,                      // lpBits
							   (LPBITMAPINFO)lpBmpHdr,         // lpBitsInfo
							   DIB_RGB_COLORS,                 // wUsage
							   SRCCOPY);                       // dwROP

   ::GlobalUnlock((HGLOBAL) m_hBmp);

	/* Reselect old palette */
	if (hOldPal != NULL)
	{
		::SelectPalette(hDC, hOldPal, TRUE);
	}

   return bSuccess;
}

/*************************************************************************
 *
 * CreateBmpPalette()
 *
 * Parameter:
 *
 * HBMP hBmp        - specifies the BMP
 *
 * Return Value:
 *
 * HPALETTE         - specifies the palette
 *
 * Description:
 *
 * This function creates a palette from a BMP by allocating memory for the
 * logical palette, reading and storing the colors from the BMP's color table
 * into the logical palette, creating a palette from this logical palette,
 * and then returning the palette's handle. This allows the BMP to be
 * displayed using the best possible colors (important for BMPs with 256 or
 * more colors).
 *
 ************************************************************************/


BOOL CBmpIO::CreateBmpPalette(HBMP hBmp, CPalette* pPal)
{
	LPLOGPALETTE lpPal;      // pointer to a logical palette
	HANDLE hLogPal;          // handle to a logical palette
	HPALETTE hPal = NULL;    // handle to a palette
	int i;                   // loop index
	WORD wNumColors;         // number of colors in color table
	LPSTR lpbi;              // pointer to packed-BMP
	LPBITMAPINFO lpbmi;      // pointer to BITMAPINFO structure
	BOOL bResult = FALSE;

	/* if handle to BMP is invalid, return FALSE */
	if (hBmp == NULL)
	  return FALSE;

	lpbi = (LPSTR) ::GlobalLock((HGLOBAL) hBmp);

	/* get pointer to BITMAPINFO */
	lpbmi = (LPBITMAPINFO)lpbi;

	/* get the number of colors in the BMP */
	wNumColors = BmpNumColors(lpbi);

	if (wNumColors != 0)
	{
		/* allocate memory block for logical palette */
		hLogPal = ::GlobalAlloc(GHND, sizeof(LOGPALETTE)
									+ sizeof(PALETTEENTRY)
									* wNumColors);

		/* if not enough memory, clean up and return NULL */
		if (hLogPal == 0)
		{
			::GlobalUnlock((HGLOBAL) hBmp);
			return FALSE;
		}

		lpPal = (LPLOGPALETTE) ::GlobalLock((HGLOBAL) hLogPal);

		/* set version and number of palette entries */
		lpPal->palVersion = PALVERSION;
		lpPal->palNumEntries = (WORD)wNumColors;

		/* load palette entries */
		for (i = 0; i < (int)wNumColors; i++)
		{
			lpPal->palPalEntry[i].peRed = lpbmi->bmiColors[i].rgbRed;
			lpPal->palPalEntry[i].peGreen = lpbmi->bmiColors[i].rgbGreen;
			lpPal->palPalEntry[i].peBlue = lpbmi->bmiColors[i].rgbBlue;
			lpPal->palPalEntry[i].peFlags = 0;
		}

		/* create the palette and get handle to it */
		bResult = pPal->CreatePalette(lpPal);
		::GlobalUnlock((HGLOBAL) hLogPal);
		::GlobalFree((HGLOBAL) hLogPal);
	}

	::GlobalUnlock((HGLOBAL) hBmp);

	return bResult;
}

/*************************************************************************
 *
 * FindBmpBits()
 *
 * Parameter:
 *
 * LPSTR lpbi       - pointer to packed-BMP memory block
 *
 * Return Value:
 *
 * LPSTR            - pointer to the BMP bits
 *
 * Description:
 *
 * This function calculates the address of the BMP's bits and returns a
 * pointer to the BMP bits.
 *
 ************************************************************************/


LPSTR CBmpIO::FindBmpBits(LPSTR lpbi)
{
	// pointer to (BmpInfoHdr + BmpInfoHdr Size (biSize) + RGBQUAD Number)
	return (lpbi + *(LPDWORD)lpbi + PaletteSize(lpbi));
}


/*************************************************************************
 *
 * PaletteSize()
 *
 * Parameter:
 *
 * LPSTR lpbi       - pointer to packed-BMP memory block
 *
 * Return Value:
 *
 * WORD             - size of the color palette of the BMP
 *
 * Description:
 *
 * This function gets the size required to store the BMP's palette by
 * multiplying the number of colors by the size of an RGBQUAD.
 *
 ************************************************************************/


WORD CBmpIO::PaletteSize(LPSTR lpbi)
{
	/* calculate the size required by the palette */
	return (WORD)(BmpNumColors(lpbi) * sizeof(RGBQUAD));
}


/*************************************************************************
 *
 * BmpNumColors()
 *
 * Parameter:
 *
 * LPSTR lpbi       - pointer to packed-BMP memory block
 *
 * Return Value:
 *
 * WORD             - number of colors in the color table
 *
 * Description:
 *
 * This function calculates the number of colors in the BMP's color table
 * by finding the bits per pixel (bpp) for the BMP. If bpp is 1: colors=2,
 * if 4: colors=16, if 8: colors=256, if 24, no colors in color table.
 *
 ************************************************************************/


WORD CBmpIO::BmpNumColors(LPSTR lpbi)
{
	WORD	wBitCount;  // BMP bit count
	DWORD	dwClrUsed;

	/*  For a BMP, the number of colors in the color table can be less
	 *  than the number of bits per pixel allows for (i.e. lpbi->biClrUsed
	 *  can be set to some value). If this is the case, return the
	 *  appropriate value.
	 */
	dwClrUsed = ((LPBITMAPINFOHEADER)lpbi)->biClrUsed;
	if (dwClrUsed != 0)
		return (WORD)dwClrUsed;

	/*  Calculate the number of colors in the color table based on
	 *  the number of bits per pixel for the BMP.
	 */
	wBitCount = ((LPBITMAPINFOHEADER)lpbi)->biBitCount;

	/* return number of colors based on bits per pixel */
	switch (wBitCount)
	{
		case 1:
			return 2;

		case 4:
			return 16;

		case 8:
			return 256;

		default:	// 24 bits
			return 0;
	}
}


/*************************************************************************
 *
 * Function:  CopyHandle (from SDK DibView sample clipbrd.c)
 *
 * Purpose:   Makes a copy of the given global memory block.  Returns
 *            a handle to the new memory block (NULL on error).
 *
 *            Routine stolen verbatim out of ShowDIB.
 *
 * Parms:     h == Handle to global memory to duplicate.
 *
 * Returns:   Handle to new global memory block.
 *
 ************************************************************************/

HGLOBAL CBmpIO::CopyHandle (HGLOBAL h)
{
	if (h == NULL)
		return NULL;

	DWORD dwLen = ::GlobalSize((HGLOBAL) h);
	HGLOBAL hCopy = ::GlobalAlloc(GHND, dwLen);

	if (hCopy != NULL)
	{
		void* lpCopy = ::GlobalLock((HGLOBAL) hCopy);
		void* lp     = ::GlobalLock((HGLOBAL) h);
		memcpy(lpCopy, lp, dwLen);
		::GlobalUnlock(hCopy);
		::GlobalUnlock(h);
	}

	return hCopy;
}


/*************************************************************************
 *
 * Function:  OpenBmp (CFile&)
 *
 * Purpose:   Reads in the specified BMP file into a global chunk of
 *			  memory.
 *
 * Returns:   A handle to a BMP (hBmp) if successful.
 *			  NULL if an error occurs.
 *
 * Comments:  BITMAPFILEHEADER is stripped off of the BMP.  Everything
 *			  from the end of the BITMAPFILEHEADER structure on is
 *			  returned in the global memory handle.
 *
 ************************************************************************/


HBMP CBmpIO::OpenBmp(CFile& file)
{
	BITMAPFILEHEADER bmfHeader;
	DWORD dwBitsSize;
	HBMP hBmp;
	LPSTR pBmp;

	/*
	 * get length of BMP in bytes for use when reading
	 */

	dwBitsSize = file.GetLength();

	/*
	 * Go read the BMP file header and check if it's valid.
	 */
	if (file.Read((LPSTR)&bmfHeader, sizeof(bmfHeader)) != sizeof(bmfHeader))
		return NULL;

	if (bmfHeader.bfType != BMP_HEADER_MARKER)
		return NULL;

	/*
	 * Allocate memory for BMP
	 */
	hBmp = (HBMP) ::GlobalAlloc(GMEM_MOVEABLE | GMEM_ZEROINIT, dwBitsSize);
	if (hBmp == 0)
	{
		return NULL;
	}
	pBmp = (LPSTR) ::GlobalLock((HGLOBAL) hBmp);

	/*
	 * Go read the bits.
	 */
	if (file.ReadHuge(pBmp, dwBitsSize - sizeof(BITMAPFILEHEADER)) !=
		dwBitsSize - sizeof(BITMAPFILEHEADER) )
	{
		::GlobalUnlock((HGLOBAL) hBmp);
		::GlobalFree((HGLOBAL) hBmp);
		return NULL;
	}
	::GlobalUnlock((HGLOBAL) hBmp);
	return hBmp;
}


/*************************************************************************
 *
 * Function:  OpenBmpFile (LPCTSTR)
 *
 * Purpose:   Open the specified BMP file
 *
 * Returns:   TRUE if successful, else FALSE.
 *
 * Comments:  used in the OnOpenDocument(LPCTSTR lpszPathName) function.
 *
 ************************************************************************/


BOOL CBmpIO::OpenBmpFile(LPCTSTR lpszPathName)
{
	CFile file;
	CFileException fe;
	if (!file.Open(lpszPathName, CFile::modeRead | CFile::shareDenyWrite, &fe))
	{
		ReportSaveLoadException(lpszPathName, &fe,
			FALSE, AFX_IDP_FAILED_TO_OPEN_DOC);
		return FALSE;
	}

	DeleteContents();
	BeginWaitCursor();

	// replace calls to Serialize with OpenBmp function
	TRY
	{
		m_hBmp = OpenBmp(file);
	}
	CATCH (CFileException, eLoad)
	{
		file.Abort(); // will not throw an exception
		EndWaitCursor();
		ReportSaveLoadException(lpszPathName, eLoad,
			FALSE, AFX_IDP_FAILED_TO_OPEN_DOC);
		m_hBmp = NULL;
		return FALSE;
	}
	END_CATCH

	InitBmpData(lpszPathName);
	EndWaitCursor();

	if (m_hBmp == NULL)
	{
		// may not be BMP format
		CString strMsg = (CString) "Cannot load BMP file:\n";
		strMsg += (CString) lpszPathName;
		MessageBox(NULL, strMsg, NULL, MB_ICONERROR | MB_OK);
		return FALSE;
	}
	SetPathName(lpszPathName);
	SetModifiedFlag(FALSE);     // start off with unmodified
	return TRUE;
}


/*************************************************************************
 *
 * SaveBmp (HBMP, CFile&)
 *
 * Saves the specified BMP into the specified CFile.  The CFile
 * is opened and closed by the caller.
 *
 * Parameters:
 *
 * HBMP hBmp - Handle to the BMP to save
 *
 * CFile& file - open CFile used to save BMP
 *
 * Return value: TRUE if successful, else FALSE or CFileException
 *
 *************************************************************************/


BOOL CBmpIO::SaveBmp(HBMP hBmp, CFile& file)
{
	BITMAPFILEHEADER bmfHdr; // Header for Bitmap file
	LPBITMAPINFOHEADER lpBI;   // Pointer to BMP info structure
	DWORD dwBmpSize;

	if (hBmp == NULL)
		return FALSE;

	/*
	 * Get a pointer to the BMP memory, the first of which contains
	 * a BITMAPINFO structure
	 */
	lpBI = (LPBITMAPINFOHEADER) ::GlobalLock((HGLOBAL) hBmp);
	if (lpBI == NULL)
		return FALSE;

	/*
	 * Fill in the fields of the file header
	 */

	/* Fill in file type (first 2 bytes must be "BM" for a bitmap) */
	bmfHdr.bfType = BMP_HEADER_MARKER;  // "BM"

	// Calculating the size of the BMP is a bit tricky (if we want to
	// do it right).  The easiest way to do this is to call GlobalSize()
	// on our global handle, but since the size of our global memory may have
	// been padded a few bytes, we may end up writing out a few too
	// many bytes to the file (which may cause problems with some apps).
	//
	// So, instead let's calculate the size manually (if we can)
	//
	// First, find size of header plus size of color table.  Since the
	// first DWORD in both BITMAPINFOHEADER and BITMAPCOREHEADER conains
	// the size of the structure, let's use this.

	dwBmpSize = *(LPDWORD)lpBI + PaletteSize((LPSTR)lpBI);  // Partial Calculation

	// Now calculate the size of the image

	if ((lpBI->biCompression == BI_RLE8) || (lpBI->biCompression == BI_RLE4))
	{
		// It's an RLE bitmap, we can't calculate size, so trust the
		// biSizeImage field

		dwBmpSize += lpBI->biSizeImage;
	}
	else
	{
		DWORD dwBmBitsSize;  // Size of Bitmap Bits only

		// It's not RLE, so size is Width (DWORD aligned) * Height

		dwBmBitsSize = WIDTHBYTES((lpBI->biWidth)*((DWORD)lpBI->biBitCount)) * lpBI->biHeight;

		dwBmpSize += dwBmBitsSize;

		// Now, since we have calculated the correct size, why don't we
		// fill in the biSizeImage field (this will fix any .Bmp files which
		// have this field incorrect).

		lpBI->biSizeImage = dwBmBitsSize;
	}


	// Calculate the file size by adding the BMP size to sizeof(BITMAPFILEHEADER)

	bmfHdr.bfSize = dwBmpSize + sizeof(BITMAPFILEHEADER);
	bmfHdr.bfReserved1 = 0;
	bmfHdr.bfReserved2 = 0;

	/*
	 * Now, calculate the offset the actual bitmap bits will be in
	 * the file -- It's the Bitmap file header plus the BMP header,
	 * plus the size of the color table.
	 */
	bmfHdr.bfOffBits = (DWORD)sizeof(BITMAPFILEHEADER) + lpBI->biSize
											  + PaletteSize((LPSTR)lpBI);
	TRY
	{
		// Write the file header
		file.Write((LPSTR)&bmfHdr, sizeof(BITMAPFILEHEADER));
		//
		// Write the BMP header and the bits
		//
		file.WriteHuge(lpBI, dwBmpSize);
	}
	CATCH (CFileException, e)
	{
		::GlobalUnlock((HGLOBAL) hBmp);
		THROW_LAST();
	}
	END_CATCH

	::GlobalUnlock((HGLOBAL) hBmp);
	return TRUE;
}


/*************************************************************************
 *
 * Function:  SaveBmpFile (LPCTSTR, HBMP)
 *
 * Purpose:   Save the specified BMP file
 *
 * Returns:   TRUE if successful, else FALSE.
 *
 * Comments:  used in the OnSaveDocument(LPCTSTR lpszPathName) function.
 *
 ************************************************************************/


BOOL CBmpIO::SaveBmpFile(LPCTSTR lpszPathName, HBMP hBmp)
{
	CFile file;
	CFileException fe;

	if (!file.Open(lpszPathName, CFile::modeCreate |
	  CFile::modeReadWrite | CFile::shareExclusive, &fe))
	{
		ReportSaveLoadException(lpszPathName, &fe,
			TRUE, AFX_IDP_INVALID_FILENAME);
		return FALSE;
	}

	// replace calls to Serialize with SaveBmp function
	BOOL bSuccess = FALSE;
	TRY
	{
		BeginWaitCursor();
		bSuccess = SaveBmp(hBmp, file);
		file.Close();
	}
	CATCH (CException, eSave)
	{
		file.Abort(); // will not throw an exception
		EndWaitCursor();
		ReportSaveLoadException(lpszPathName, eSave,
			TRUE, AFX_IDP_FAILED_TO_SAVE_DOC);
		return FALSE;
	}
	END_CATCH

	EndWaitCursor();
	SetModifiedFlag(FALSE);     // back to unmodified

	if (!bSuccess)
	{
		// may be other-style BMP (load supported but not save)
		//  or other problem in SaveBmp
		CString strMsg = (CString) "Cannot save BMP file:\n";
		strMsg += (CString) lpszPathName;
		MessageBox(NULL, strMsg, NULL, MB_ICONERROR | MB_OK);
	}

	return bSuccess;
}
